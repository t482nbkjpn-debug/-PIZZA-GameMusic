package com.pizza.gamemusic

import android.app.*
import android.content.*
import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.widget.*
import java.util.*

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private var dark = false
    private var pizzaSplash: ImageView? = null
    private var playerVolume = 0.65f
    private val white = Color.WHITE
    private val bg = Color.rgb(10,10,10)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showSplashThenHome()
    }

    private fun showSplashThenHome() {
        val img = ImageView(this).apply { setImageResource(com.pizza.gamemusic.R.drawable.pizza_splash); scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(Color.BLACK) }
        pizzaSplash = img
        setContentView(img)
        img.postDelayed({ showHome() }, 1300)
    }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(20,24,20,16)
    }
    private fun text(s:String, size:Float, bold:Boolean=false): TextView = TextView(this).apply {
        text=s; textSize=size; setTextColor(white); setPadding(0,6,0,6); if(bold) setTypeface(typeface,Typeface.BOLD)
    }
    private fun button(s:String, action:()->Unit): Button = Button(this).apply { text=s; setTextColor(white); setOnClickListener{action()}; setBackgroundColor(Color.rgb(32,32,32)) }

    private fun showHome() {
        root=base();
        val title=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        title.addView(text("🍕  P I Z Z A",28,true),LinearLayout.LayoutParams(0,70,1f))
        title.addView(button("⚙") { showSettings() },LinearLayout.LayoutParams(64,64))
        root.addView(title)
        root.addView(text("GameMusic  •  Play • Game • Enjoy",14))
        val search=EditText(this).apply{hint="Search for a song, artist or game…";setHintTextColor(Color.GRAY);setTextColor(white);setSingleLine();setBackgroundColor(Color.rgb(25,25,25));setPadding(20,0,20,0)}
        root.addView(search,LinearLayout.LayoutParams(-1,58))
        root.addView(text("Popular & Game Music",20,true))
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        listOf("🎵 Music","▶ YouTube","🌐 Browser").forEach{ label-> row.addView(button(label){when(label){"🎵 Music"->showPlayer();"▶ YouTube"->openUrl("https://www.youtube.com");else->showBrowser() }},LinearLayout.LayoutParams(0,62,1f)) }
        root.addView(row)
        root.addView(text("Quick Access",20,true))
        val grid=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        listOf("❤️ Favorites","📂 Playlists","⬇ Downloads","🎮 Gaming Music").chunked(2).forEach{ pair->
            val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
            pair.forEach{label->r.addView(button(label){Toast.makeText(this@MainActivity,"$label — ready",Toast.LENGTH_SHORT).show()},LinearLayout.LayoutParams(0,62,1f))}
            grid.addView(r)
        }
        root.addView(grid)
        root.addView(text("Background playback is designed for gaming sessions. Player controls are available from Now Playing.",13))
        setContentView(root)
    }

    private fun showPlayer(){
        root=base(); root.addView(button("‹  Back"){showHome()})
        val art=ImageView(this).apply{setImageResource(R.drawable.pizza_splash);scaleType=ImageView.ScaleType.CENTER_CROP}
        root.addView(art,LinearLayout.LayoutParams(-1,330))
        root.addView(text("Battle Mode",24,true),LinearLayout.LayoutParams(-1,50))
        root.addView(text("PIZZA GameMusic",15))
        val seek=SeekBar(this).apply{max=100;progress=8}
        root.addView(seek)
        val times=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;addView(text("0:05",12),LinearLayout.LayoutParams(0,40,1f));addView(text("3:18",12),LinearLayout.LayoutParams(0,40,1f))}
        root.addView(times)
        val controls=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
        listOf("⏮","↶15","▶","↷15","⏭").forEach{label->controls.addView(button(label){if(label=="▶") Toast.makeText(this@MainActivity,"Playing",Toast.LENGTH_SHORT).show()},LinearLayout.LayoutParams(0,64,1f))}
        root.addView(controls)
        root.addView(text("🎚 Music Volume",15,true))
        val vol=SeekBar(this).apply{max=100;progress=(playerVolume*100).toInt();setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(s:SeekBar?,p:Int,f:Boolean){playerVolume=p/100f};override fun onStartTrackingTouch(s:SeekBar?){};override fun onStopTrackingTouch(s:SeekBar?){} })}
        root.addView(vol)
        root.addView(text("❤️   🔀   🔁   ⛶   ⋮",24))
        root.addView(text("Up Next",16,true));root.addView(text("Safir Haji — Haydeh — Bia bargardim…",14))
        setContentView(root)
    }

    private fun showSettings(){
        root=base();root.addView(button("‹  Back"){showHome()});root.addView(text("Settings",30,true))
        val darkSwitch=Switch(this).apply{text="Dark Mode";setTextColor(white);isChecked=dark;setOnCheckedChangeListener{_,v->dark=v; if(v){bgDark()}else{bgLight()}}}
        root.addView(darkSwitch)
        root.addView(text("Appearance",18,true));root.addView(text("Dark Mode removes the pizza artwork and uses a clean black screen with white system-style text.",14))
        root.addView(button("🔊 Music & Player"){showPlayer()})
        root.addView(button("🌐 Browser"){showBrowser()})
        root.addView(button("▶ YouTube"){openUrl("https://www.youtube.com")})
        root.addView(button("ℹ About PIZZA GameMusic"){Toast.makeText(this,"PIZZA GameMusic 1.0.0",Toast.LENGTH_SHORT).show()})
        setContentView(root)
    }
    private fun bgDark(){ root.setBackgroundColor(Color.BLACK); for(i in 0 until root.childCount){(root.getChildAt(i) as? TextView)?.setTextColor(Color.WHITE)} }
    private fun bgLight(){ root.setBackgroundColor(Color.rgb(10,10,10)) }

    private fun showBrowser(){
        root=base();root.addView(button("‹  Back"){showHome()});root.addView(text("🌐 PIZZA Browser",26,true))
        val url=EditText(this).apply{hint="Search Google or enter URL";setHintTextColor(Color.GRAY);setTextColor(white);setSingleLine()}
        root.addView(url)
        val go=button("Search / Open"){var s=url.text.toString().trim();if(s.isNotEmpty()){if(!s.startsWith("http"))s="https://www.google.com/search?q="+Uri.encode(s);openUrl(s)}}
        root.addView(go)
        root.addView(button("Google"){openUrl("https://www.google.com")})
        root.addView(button("Bing"){openUrl("https://www.bing.com")})
        root.addView(button("DuckDuckGo"){openUrl("https://duckduckgo.com")})
        root.addView(button("YouTube"){openUrl("https://www.youtube.com")})
        root.addView(text("Browser uses your device's secure browser/custom tab. Downloads are only for content the source allows you to download.",13))
        setContentView(root)
    }
    private fun openUrl(url:String){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)))}
}
