# PIZZA GameMusic — Android

PIZZA GameMusic is an Android starter app for a gaming-focused music player.

## Current UI
- Pizza splash screen
- P I Z Z A branding
- Dark player UI
- Music volume control inside the app
- Player controls and Up Next UI
- Dark Mode setting
- Google / Bing / DuckDuckGo / YouTube browser shortcuts
- Foreground-media permissions prepared in the manifest

## Build the APK in GitHub Actions
1. Create a GitHub repository and upload this project.
2. Open **Actions → Build PIZZA GameMusic APK → Run workflow**.
3. Download the `PIZZA-GameMusic-APK` artifact.
4. To publish a release, create a tag such as `v1.0.0`; the workflow attaches the APK to the GitHub release.

The project is intentionally kept dependency-light so the cloud build can run with Gradle 8.7, Android Gradle Plugin 8.7.3 and Kotlin 2.0.21.

## Important
This is a build-ready starter, not yet a finished production music service. Real streaming/search/download backends and device-specific background-audio testing still need to be connected.
